#include "matrixmultiply_cpu.hpp"
#include "scheduler_cpu.hpp"

#include <algorithm>
#include <thread>
#include <random>
#include <fstream>
#include <iostream>
#include <cmath>

void MatrixMultiply::FreeHostMemory()
{
  if (m_hA) free(m_hA);
  if (m_hB) free(m_hB);
  if (m_hC) free(m_hC);
  if (m_hCheckC) free(m_hCheckC);
  m_hA = m_hB = m_hC = m_hCheckC = NULL;
}

void MatrixMultiply::FreeDeviceMemory()
{
  // No-op in CPU mode
}

void MatrixMultiply::InitializeData(int matrixSize, int blockWidth, int kernelNum)
{
  m_matrixSize = matrixSize;
  m_blockWidth = blockWidth;
  m_kernelNum = kernelNum;

  m_hA = (float*)malloc(sizeof(float) * matrixSize * matrixSize);
  m_hB = (float*)malloc(sizeof(float) * matrixSize * matrixSize);
  m_hC = (float*)malloc(sizeof(float) * matrixSize * matrixSize);
  m_hCheckC = (float*)malloc(sizeof(float) * matrixSize * matrixSize);

  m_blocksRequired = matrixSize % blockWidth == 0 ? (matrixSize / blockWidth) : 1 + (matrixSize / blockWidth);
  m_globalMemRequired = 3 * sizeof(float) * matrixSize * matrixSize;

  m_floatingPointOps = matrixSize * matrixSize * (8 + m_blocksRequired * (9 + blockWidth * 6.0f));
  m_memBytesReadWrite = 4 * (matrixSize * matrixSize * (1 + m_blocksRequired * (4 + blockWidth * 2.0f)));

  for (int i = 0; i < matrixSize*matrixSize; i++) {
    m_hA[i] = 2.0f;
    m_hB[i] = 1.0f;
    m_hCheckC[i] = 0.0f; // We'll compute true check after multiply
  }
}

int MatrixMultiply::AcquireDeviceResources(std::vector< DeviceInfo > *deviceInfo)
{
  std::lock_guard< std::mutex > guard(Scheduler::m_deviceInfoMutex);

  int maxMemoryAvailableDevice = -1;
  std::size_t maxMemoryAvailable = 0;

  for (int deviceNum = 0; deviceNum < (int)deviceInfo->size(); ++deviceNum)
  {
    DeviceInfo &device = deviceInfo->operator[](deviceNum);
    if (m_globalMemRequired < device.m_remainingGlobalMem && m_blocksRequired < device.m_remainingBlocksDimX)
    {
      if (maxMemoryAvailableDevice == -1 || device.m_remainingGlobalMem > maxMemoryAvailable)
      {
        maxMemoryAvailableDevice = deviceNum;
        maxMemoryAvailable = device.m_remainingGlobalMem;
      }
    }
  }

  if (maxMemoryAvailableDevice != -1)
  {
    DeviceInfo &device = deviceInfo->operator[](maxMemoryAvailableDevice);
    if (Scheduler::m_verbose) std::cout << "** Kernel " << m_kernelNum << " acquired CPU slot " << maxMemoryAvailableDevice << " **\n";
    device.m_remainingGlobalMem -= m_globalMemRequired;
    device.m_remainingBlocksDimX -= m_blocksRequired;
  }

  return maxMemoryAvailableDevice;
}

void MatrixMultiply::ReleaseDeviceResources(std::vector< DeviceInfo > *deviceInfo)
{
  std::lock_guard< std::mutex > guard(Scheduler::m_deviceInfoMutex);
  DeviceInfo &device = deviceInfo->operator[](m_deviceNum);

  if (Scheduler::m_verbose) std::cout << "** Kernel " << m_kernelNum << " released CPU slot " << m_deviceNum << " **\n";
  device.m_remainingGlobalMem += m_globalMemRequired;
  device.m_remainingBlocksDimX += m_blocksRequired;
}

static void cpuMatrixMultiplyBlocked(int N, int blockWidth, const float* A, const float* B, float* C)
{
  // Simple blocked matrix multiplication to mimic GPU blocking
  std::fill(C, C + N*N, 0.0f);
  for (int ii = 0; ii < N; ii += blockWidth)
    for (int jj = 0; jj < N; jj += blockWidth)
      for (int kk = 0; kk < N; kk += blockWidth)
        for (int i = ii; i < std::min(ii + blockWidth, N); ++i)
          for (int j = jj; j < std::min(jj + blockWidth, N); ++j)
            for (int k = kk; k < std::min(kk + blockWidth, N); ++k)
              C[i*N + j] += A[i*N + k] * B[k*N + j];
}

void MatrixMultiply::FinishHostExecution(bool freeHostMemory)
{
  std::chrono::duration< double > diffQueue(m_streamStarted - m_queueStarted);
  m_queueTimeMS = (float)(1000.0 * diffQueue.count());

  std::chrono::duration< double > diffKernel(m_streamFinished - m_streamStarted);
  m_kernelExecTimeMS = (float)(1000.0 * diffKernel.count());
  m_totalExecTimeMS = m_kernelExecTimeMS;

  m_MFLOPs = (m_kernelExecTimeMS > 0.0f) ? (m_floatingPointOps / (m_kernelExecTimeMS * 1000.0f)) : 0.0f;
  m_MBps = (m_kernelExecTimeMS > 0.0f) ? (m_memBytesReadWrite * 1000.0f / (m_kernelExecTimeMS * 1024.0f * 1024.0f)) : 0.0f;

  // Compute CPU check for validation
  std::fill(m_hCheckC, m_hCheckC + m_matrixSize*m_matrixSize, 0.0f);
  for (int i = 0; i < m_matrixSize; ++i)
    for (int j = 0; j < m_matrixSize; ++j)
      for (int k = 0; k < m_matrixSize; ++k)
        m_hCheckC[i*m_matrixSize + j] += m_hA[i*m_matrixSize + k] * m_hB[k*m_matrixSize + j];

  bool correct(true);
  for (int m = 0; m < m_matrixSize*m_matrixSize; m++) {
    correct = correct && (std::ceil(m_hC[m]) == std::ceil(m_hCheckC[m]));
  }

  if (Scheduler::m_verbose)
    printf("Kernel %d >> Device: %d, Queue: %.3fms, Kernel: %.3fms, Total: %.3fms, MFLOP/s: %.2f, MB/s: %.2f, Correct: %s\n",
           m_kernelNum, m_deviceNum, m_queueTimeMS, m_kernelExecTimeMS, m_totalExecTimeMS, m_MFLOPs, m_MBps, correct ? "True" : "False");

  if (freeHostMemory) FreeHostMemory();
}

void RunKernelThreaded(BatchMatrixMultiply *batch, int kernelNum)
{
  MatrixMultiply &kernel = *(batch->m_data[kernelNum]);

  int deviceNum = -1;
  bool firstAttempt = true;

  kernel.m_queueStarted = std::chrono::high_resolution_clock::now();

  while (deviceNum < 0)
  {
    if (!firstAttempt)
      std::this_thread::sleep_for(std::chrono::milliseconds(10));
    firstAttempt = false;
    deviceNum = kernel.AcquireDeviceResources(&Scheduler::m_deviceInfo);
  }

  kernel.m_deviceNum = deviceNum;
  kernel.m_streamStarted = std::chrono::high_resolution_clock::now();

  cpuMatrixMultiplyBlocked(kernel.m_matrixSize, kernel.m_blockWidth, kernel.m_hA, kernel.m_hB, kernel.m_hC);

  kernel.m_streamFinished = std::chrono::high_resolution_clock::now();

  kernel.ReleaseDeviceResources(&Scheduler::m_deviceInfo);
}

void BatchMatrixMultiply::GenerateData()
{
  m_data.resize(m_batchSize);

  std::normal_distribution< float > normalDist((float)m_meanMatrixSize, 0.1f*m_meanMatrixSize);
  std::default_random_engine randomGen(m_batchSize);
  std::srand(m_batchSize);

  if (Scheduler::m_verbose) std::cout << "** Generating data **\n\tBatch Size: " << m_batchSize << ", Matrix Size: "
                                      << m_meanMatrixSize << ", Block Width: " << m_blockWidth << "\n";

  for (int kernelNum = 0; kernelNum < m_batchSize; ++kernelNum)
  {
    m_data[kernelNum] = new MatrixMultiply;
    m_data[kernelNum]->InitializeData((int)normalDist(randomGen), m_blockWidth, kernelNum);
  }

  if (Scheduler::m_verbose) std::cout << "** Done generating data **\n\n";
}

void BatchMatrixMultiply::ComputeBatchResults()
{
  Time firstStarted, lastFinished;
  m_batchFloatingPointOps = m_batchMemBytesReadWrite = 0;
  for (int kernel = 0; kernel < (int)m_data.size(); ++kernel)
  {
    if (kernel == 0) { firstStarted = m_data[kernel]->m_streamStarted; lastFinished = m_data[kernel]->m_streamFinished; }
    else {
      if (m_data[kernel]->m_streamStarted < firstStarted) firstStarted = m_data[kernel]->m_streamStarted;
      if (m_data[kernel]->m_streamFinished > lastFinished) lastFinished = m_data[kernel]->m_streamFinished;
    }
    m_batchFloatingPointOps += m_data[kernel]->m_floatingPointOps;
    m_batchMemBytesReadWrite += m_data[kernel]->m_memBytesReadWrite;
  }
  std::chrono::duration< double > diff(lastFinished - firstStarted);
  m_batchTotalExecTimeMS = (float)(1000.0 * diff.count());
  m_batchGFLOPs = (float)(m_batchFloatingPointOps / ((1024.0*1024.0*1024.0) * (m_batchTotalExecTimeMS / 1000.0)));
  m_batchGBps = (float)(m_batchMemBytesReadWrite / ((1024.0*1024.0*1024.0) * (m_batchTotalExecTimeMS / 1000.0)));
}

void BatchMatrixMultiply::OutputResultsCSV(const std::string &kernelName)
{
  std::string filenameKernel = kernelName + std::string("KernelResults.csv");
  std::ofstream csvKernelFile(filenameKernel.c_str(), std::ios::app);

  csvKernelFile.seekp(0, std::ios_base::beg);
  std::size_t posFirst = csvKernelFile.tellp();
  csvKernelFile.seekp(0, std::ios_base::end);
  std::size_t posLast = csvKernelFile.tellp();
  if (posLast - posFirst == 0)
  {
    csvKernelFile << "BatchSize, KernelName, MeanMatrixSize, BlockWidth, MaxDevices, KernelNum, QueueTimeMS"
                  << ", KernelExecTimeMS, TotalExecTimeMS, FloatingPtOps, MemBytes, MFLOPs, MBps\n";
  }

  for (int kernelNum = 0; kernelNum < (int)m_data.size(); ++kernelNum)
  {
    const MatrixMultiply &kernel = *m_data[kernelNum];

    csvKernelFile << m_batchSize << ", " << kernelName.c_str() << ", " << m_meanMatrixSize << ", " << m_blockWidth
                  << ", " << Scheduler::m_maxDevices << ", " << kernel.m_kernelNum << ", " << kernel.m_queueTimeMS
                  << ", " << kernel.m_kernelExecTimeMS << ", " << kernel.m_totalExecTimeMS
                  << ", " << kernel.m_floatingPointOps << ", " << kernel.m_memBytesReadWrite
                  << ", " << kernel.m_MFLOPs << ", " << kernel.m_MBps << "\n";
  }

  std::string filenameBatch = kernelName + std::string("BatchResults.csv");
  std::ofstream csvBatchFile(filenameBatch.c_str(), std::ios::app);

  csvBatchFile.seekp(0, std::ios_base::beg);
  posFirst = csvBatchFile.tellp();
  csvBatchFile.seekp(0, std::ios_base::end);
  posLast = csvBatchFile.tellp();
  if (posLast - posFirst == 0)
  {
    csvBatchFile << "BatchSize, KernelName, MeanMatrixSize, BlockWidth, MaxDevices, BatchTotalExecTimeMS"
                 << ", FloatingPtOps, MemBytes, GFLOPs, GBps\n";
  }

  csvBatchFile << m_batchSize << ", " << kernelName.c_str() << ", " << m_meanMatrixSize << ", " << m_blockWidth
               << ", " << Scheduler::m_maxDevices << ", " << m_batchTotalExecTimeMS << ", " << m_batchFloatingPointOps
               << ", " << m_batchMemBytesReadWrite << ", " << m_batchGFLOPs << ", " << m_batchGBps << "\n";
}

void BatchMatrixMultiply::RunExperiment(const std::string &kernelName, int numRepeat)
{
  Scheduler::GetDeviceInfo();
  GenerateData();

  for (int n = 0; n < numRepeat; ++n)
  {
    std::vector<std::thread> threads(m_data.size());
    for (int kernelNum = 0; kernelNum < (int)m_data.size(); ++kernelNum)
      threads[kernelNum] = std::thread(RunKernelThreaded, this, kernelNum);

    for (auto &t : threads) t.join();

    if (Scheduler::m_verbose) std::cout << "\n** Kernel Results **\n";
    bool freeHostMemory = n == (numRepeat - 1);
    for (int kernelNum = 0; kernelNum < (int)m_data.size(); ++kernelNum)
      m_data[kernelNum]->FinishHostExecution(freeHostMemory);

    ComputeBatchResults();
    OutputResultsCSV(kernelName);
  }
}
