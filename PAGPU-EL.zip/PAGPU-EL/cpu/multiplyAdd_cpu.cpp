#include "multiplyAdd_cpu.hpp"
#include "scheduler_cpu.hpp"

#include <algorithm>
#include <thread>
#include <random>
#include <fstream>
#include <iostream>

void MultiplyAdd::FreeHostMemory()
{
  if (m_hA) free(m_hA);
  if (m_hB) free(m_hB);
  if (m_hC) free(m_hC);
  if (m_hCheckC) free(m_hCheckC);
  m_hA = m_hB = m_hC = m_hCheckC = NULL;
}

void MultiplyAdd::FreeDeviceMemory()
{
  // No-op for CPU mode
}

void MultiplyAdd::InitializeData(int vectorSize, int threadsPerBlock, int kernelNum)
{
  m_vectorSize = vectorSize;
  m_kernelNum = kernelNum;

  m_hA = (float*)malloc(sizeof(float) * vectorSize);
  m_hB = (float*)malloc(sizeof(float) * vectorSize);
  m_hC = (float*)malloc(sizeof(float) * vectorSize);
  m_hCheckC = (float*)malloc(sizeof(float) * vectorSize);

  m_blocksRequired = vectorSize % threadsPerBlock == 0 ? (vectorSize / threadsPerBlock) : 1 + (vectorSize / threadsPerBlock);
  m_globalMemRequired = 3 * sizeof(float) * vectorSize;

  m_floatingPointOps = (float)(2 * m_vectorSize);
  m_memBytesReadWrite = (float)(3 * sizeof(float) * m_vectorSize);

  float invRandMax = 1000.0f / RAND_MAX;
  for (int n = 0; n < vectorSize; ++n)
  {
    m_hA[n] = std::rand() * invRandMax;
    m_hB[n] = std::rand() * invRandMax;
    m_hCheckC[n] = (m_hA[n] + m_hB[n]) * 2.0f;
  }
}

int MultiplyAdd::AcquireDeviceResources(std::vector< DeviceInfo > *deviceInfo)
{
  std::lock_guard< std::mutex > guard(Scheduler::m_deviceInfoMutex);

  int maxMemoryAvailableDevice = -1;
  std::size_t maxMemoryAvailable = 0;

  for (int deviceNum = 0; deviceNum < (int)deviceInfo->size(); ++deviceNum)
  {
    DeviceInfo &device = deviceInfo->operator[](deviceNum);
    if (m_globalMemRequired < device.m_remainingGlobalMem && m_blocksRequired < device.m_remainingBlocksDimX)
    {
      if (maxMemoryAvailableDevice == -1 || device.m_remainingGlobalMem > maxMemoryAvailable)
      {
        maxMemoryAvailableDevice = deviceNum;
        maxMemoryAvailable = device.m_remainingGlobalMem;
      }
    }
  }

  if (maxMemoryAvailableDevice != -1)
  {
    DeviceInfo &device = deviceInfo->operator[](maxMemoryAvailableDevice);
    if (Scheduler::m_verbose) std::cout << "** Kernel " << m_kernelNum << " acquired CPU slot " << maxMemoryAvailableDevice << " **\n";
    device.m_remainingGlobalMem -= m_globalMemRequired;
    device.m_remainingBlocksDimX -= m_blocksRequired;
  }

  return maxMemoryAvailableDevice;
}

void MultiplyAdd::ReleaseDeviceResources(std::vector< DeviceInfo > *deviceInfo)
{
  std::lock_guard< std::mutex > guard(Scheduler::m_deviceInfoMutex);
  DeviceInfo &device = deviceInfo->operator[](m_deviceNum);

  if (Scheduler::m_verbose) std::cout << "** Kernel " << m_kernelNum << " released CPU slot " << m_deviceNum << " **\n";
  device.m_remainingGlobalMem += m_globalMemRequired;
  device.m_remainingBlocksDimX += m_blocksRequired;
}

void MultiplyAdd::FinishHostExecution(bool freeHostMemory)
{
  std::chrono::duration< double > diffQueue(m_streamStarted - m_queueStarted);
  m_queueTimeMS = (float)(1000.0 * diffQueue.count());

  std::chrono::duration< double > diffKernel(m_streamFinished - m_streamStarted);
  m_kernelExecTimeMS = (float)(1000.0 * diffKernel.count());
  m_totalExecTimeMS = m_kernelExecTimeMS; // Approximate total time in CPU mode

  m_MFLOPs = (m_kernelExecTimeMS > 0.0f) ? (m_floatingPointOps / (m_kernelExecTimeMS * 1000.0f)) : 0.0f;
  m_MBps = (m_kernelExecTimeMS > 0.0f) ? (m_memBytesReadWrite * 1000.0f / (m_kernelExecTimeMS * 1024.0f * 1024.0f)) : 0.0f;

  bool correct(true);
  for (int n = 0; n < m_vectorSize; ++n)
    correct = correct && (m_hC[n] == m_hCheckC[n]);

  if (Scheduler::m_verbose)
    printf("Kernel %d >> Device: %d, Queue: %.3fms, Kernel: %.3fms, Total: %.3fms, MFLOP/s: %.2f, MB/s: %.2f, Correct: %s\n",
           m_kernelNum, m_deviceNum, m_queueTimeMS, m_kernelExecTimeMS, m_totalExecTimeMS, m_MFLOPs, m_MBps, correct ? "True" : "False");

  if (freeHostMemory) FreeHostMemory();
}

static void cpuMultiplyAdd(int n, const float* A, const float* B, float* C)
{
  for (int i = 0; i < n; ++i)
    C[i] = (A[i] + B[i]) * 2.0f;
}

void RunKernelThreaded(BatchMultiplyAdd *batch, int kernelNum)
{
  MultiplyAdd &kernel = *(batch->m_data[kernelNum]);

  int deviceNum = -1;
  bool firstAttempt = true;

  kernel.m_queueStarted = std::chrono::high_resolution_clock::now();

  while (deviceNum < 0)
  {
    if (!firstAttempt)
      std::this_thread::sleep_for(std::chrono::milliseconds(10));
    firstAttempt = false;
    deviceNum = kernel.AcquireDeviceResources(&Scheduler::m_deviceInfo);
  }

  kernel.m_deviceNum = deviceNum;
  kernel.m_streamStarted = std::chrono::high_resolution_clock::now();

  // Execute on CPU
  cpuMultiplyAdd(kernel.m_vectorSize, kernel.m_hA, kernel.m_hB, kernel.m_hC);

  kernel.m_streamFinished = std::chrono::high_resolution_clock::now();

  kernel.ReleaseDeviceResources(&Scheduler::m_deviceInfo);
}

void BatchMultiplyAdd::GenerateData()
{
  m_data.resize(m_batchSize);

  std::normal_distribution< float > normalDist((float)m_meanVectorSize, 0.1f*m_meanVectorSize);
  std::default_random_engine randomGen(m_batchSize);
  std::srand(m_batchSize);

  if (Scheduler::m_verbose) std::cout << "** Generating data **\n\tBatch Size: " << m_batchSize << ", Vector Size: "
                                      << m_meanVectorSize << ", Threads Per Block: " << m_threadsPerBlock << "\n";

  for (int k = 0; k < m_batchSize; ++k)
  {
    m_data[k] = new MultiplyAdd;
    m_data[k]->InitializeData((int)normalDist(randomGen), m_threadsPerBlock, k);
  }

  if (Scheduler::m_verbose) std::cout << "** Done generating data **\n\n";
}

void BatchMultiplyAdd::ComputeBatchResults()
{
  Time firstStarted, lastFinished;
  m_batchFloatingPointOps = m_batchMemBytesReadWrite = 0;
  for (int k = 0; k < (int)m_data.size(); ++k)
  {
    if (k == 0) { firstStarted = m_data[k]->m_streamStarted; lastFinished = m_data[k]->m_streamFinished; }
    else {
      if (m_data[k]->m_streamStarted < firstStarted) firstStarted = m_data[k]->m_streamStarted;
      if (m_data[k]->m_streamFinished > lastFinished) lastFinished = m_data[k]->m_streamFinished;
    }
    m_batchFloatingPointOps += m_data[k]->m_floatingPointOps;
    m_batchMemBytesReadWrite += m_data[k]->m_memBytesReadWrite;
  }
  std::chrono::duration< double > diff(lastFinished - firstStarted);
  m_batchTotalExecTimeMS = (float)(1000.0 * diff.count());
  m_batchGFLOPs = (float)(m_batchFloatingPointOps / ((1024.0*1024.0*1024.0) * (m_batchTotalExecTimeMS / 1000.0)));
  m_batchGBps = (float)(m_batchMemBytesReadWrite / ((1024.0*1024.0*1024.0) * (m_batchTotalExecTimeMS / 1000.0)));
}

void BatchMultiplyAdd::OutputResultsCSV(const std::string &kernelName)
{
  std::string filenameKernel = kernelName + std::string("KernelResults.csv");
  std::ofstream csvKernelFile(filenameKernel.c_str(), std::ios::app);

  csvKernelFile.seekp(0, std::ios_base::beg);
  std::size_t posFirst = csvKernelFile.tellp();
  csvKernelFile.seekp(0, std::ios_base::end);
  std::size_t posLast = csvKernelFile.tellp();
  if (posLast - posFirst == 0)
  {
    csvKernelFile << "BatchSize, KernelName, MeanVectorSize, ThreadsPerBlock, MaxDevices, KernelNum, QueueTimeMS"
                  << ", KernelExecTimeMS, TotalExecTimeMS, FloatingPtOps, MemBytes, MFLOPs, MBps\n";
  }

  for (int kernelNum = 0; kernelNum < (int)m_data.size(); ++kernelNum)
  {
    const MultiplyAdd &kernel = *m_data[kernelNum];
    csvKernelFile << m_batchSize << ", " << kernelName.c_str() << ", " << m_meanVectorSize << ", " << m_threadsPerBlock
                  << ", " << Scheduler::m_maxDevices << ", " << kernel.m_kernelNum << ", " << kernel.m_queueTimeMS
                  << ", " << kernel.m_kernelExecTimeMS << ", " << kernel.m_totalExecTimeMS << ", " << kernel.m_floatingPointOps
                  << ", " << kernel.m_memBytesReadWrite << ", " << kernel.m_MFLOPs << ", " << kernel.m_MBps << "\n";
  }

  std::string filenameBatch = kernelName + std::string("BatchResults.csv");
  std::ofstream csvBatchFile(filenameBatch.c_str(), std::ios::app);

  csvBatchFile.seekp(0, std::ios_base::beg);
  posFirst = csvBatchFile.tellp();
  csvBatchFile.seekp(0, std::ios_base::end);
  posLast = csvBatchFile.tellp();
  if (posLast - posFirst == 0)
  {
    csvBatchFile << "BatchSize, KernelName, MeanVectorSize, ThreadsPerBlock, MaxDevices, BatchTotalExecTimeMS"
                 << ", FloatingPtOps, MemBytes, GFLOPs, GBps\n";
  }

  csvBatchFile << m_batchSize << ", " << kernelName.c_str() << ", " << m_meanVectorSize << ", " << m_threadsPerBlock
               << ", " << Scheduler::m_maxDevices << ", " << m_batchTotalExecTimeMS
               << ", " << m_batchFloatingPointOps << ", " << m_batchMemBytesReadWrite << ", " << m_batchGFLOPs
               << ", " << m_batchGBps << "\n";
}

void BatchMultiplyAdd::RunExperiment(const std::string &kernelName, int numRepeat)
{
  Scheduler::GetDeviceInfo();
  GenerateData();

  for (int n = 0; n < numRepeat; ++n)
  {
    std::vector<std::thread> threads(m_data.size());
    for (int kernelNum = 0; kernelNum < (int)m_data.size(); ++kernelNum)
      threads[kernelNum] = std::thread(RunKernelThreaded, this, kernelNum);

    for (auto &t : threads) t.join();

    if (Scheduler::m_verbose) std::cout << "\n** Kernel Results **\n";
    bool freeHostMemory = n == (numRepeat - 1);
    for (int kernelNum = 0; kernelNum < (int)m_data.size(); ++kernelNum)
      m_data[kernelNum]->FinishHostExecution(freeHostMemory);

    ComputeBatchResults();
    OutputResultsCSV(kernelName);
  }
}
