#include "scheduler_cpu.hpp"

#include <climits>

std::vector< DeviceInfo > Scheduler::m_deviceInfo = std::vector< DeviceInfo >();
int Scheduler::m_maxDevices = 0;
bool Scheduler::m_verbose = false;
std::mutex Scheduler::m_deviceInfoMutex;

void DeviceInfo::SetDeviceInfo(int /*deviceNum*/)
{
  // Simulate a very large memory and block capacity for CPU devices
  m_totalGlobalMem = static_cast<std::size_t>(1024ull * 1024ull * 1024ull * 1024ull); // 1 TB
  m_remainingGlobalMem = m_totalGlobalMem;
  m_totalBlocksDimX = INT_MAX / 16;
  m_remainingBlocksDimX = m_totalBlocksDimX;
  m_totalCores = 1; // Not used by scheduler in CPU mode
  m_remainingTotalCores = m_totalCores;
}

void Scheduler::GetDeviceInfo()
{
  int numDevices = (m_maxDevices > 0) ? m_maxDevices : 1; // Treat maxDevices as CPU threads/devices
  m_deviceInfo.resize(numDevices);
  for (int deviceNum = 0; deviceNum < numDevices; ++deviceNum)
    m_deviceInfo[deviceNum].SetDeviceInfo(deviceNum);
}
