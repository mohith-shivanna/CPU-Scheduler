#ifndef MULTIPLYADD_CPU_HPP
#define MULTIPLYADD_CPU_HPP

#include <vector>
#include <chrono>
#include <cstddef>

#include "scheduler_cpu.hpp"

typedef std::chrono::time_point<std::chrono::high_resolution_clock> Time;

class MultiplyAdd : public ScheduledKernel
{
public:
  MultiplyAdd()
    : m_hA(NULL), m_hB(NULL), m_hC(NULL), m_hCheckC(NULL)
  {}

  ~MultiplyAdd()
  {
    FreeHostMemory();
    FreeDeviceMemory();
  }

  void FreeHostMemory();
  void FreeDeviceMemory();

  void InitializeData(int vectorSize, int threadsPerBlock, int kernelNum);
  void FinishHostExecution(bool freeHostMemory);

  virtual int  AcquireDeviceResources(std::vector< DeviceInfo > *deviceInfo);
  virtual void ReleaseDeviceResources(std::vector< DeviceInfo > *deviceInfo);

  int   m_vectorSize;
  float *m_hA, *m_hB, *m_hC, *m_hCheckC;

  std::size_t m_globalMemRequired;
  int m_blocksRequired;

  float m_floatingPointOps;
  float m_MFLOPs;
  float m_memBytesReadWrite;
  float m_MBps;

  int m_kernelNum, m_deviceNum;
  float m_queueTimeMS, m_kernelExecTimeMS, m_totalExecTimeMS;

  Time m_queueStarted, m_streamStarted, m_streamFinished;
};

class BatchMultiplyAdd
{
public:
  BatchMultiplyAdd(int meanVectorSize, int batchSize, int threadsPerBlock)
    : m_meanVectorSize(meanVectorSize), m_batchSize(batchSize), m_threadsPerBlock(threadsPerBlock)
  {}

  ~BatchMultiplyAdd()
  {
    for (auto it = m_data.begin(); it != m_data.end(); ++it)
      if (*it) delete *it;
  }

  void RunExperiment(const std::string &kernelName, int numRepeat);
  void ComputeBatchResults();
  void OutputResultsCSV(const std::string &kernelName);
  friend void RunKernelThreaded(BatchMultiplyAdd *batch, int kernelNum);

private:
  void GenerateData();
 
  std::vector< MultiplyAdd* > m_data;
  int m_meanVectorSize, m_batchSize, m_threadsPerBlock;

  float m_batchTotalExecTimeMS;

  float m_batchFloatingPointOps;
  float m_batchGFLOPs;
 
  float m_batchMemBytesReadWrite;
  float m_batchGBps;
};

#endif // MULTIPLYADD_CPU_HPP
