#ifndef MATRIXMULTIPLY_CPU_HPP
#define MATRIXMULTIPLY_CPU_HPP

#include <vector>
#include <chrono>
#include <cstddef>

#include "scheduler_cpu.hpp"

typedef std::chrono::time_point<std::chrono::high_resolution_clock> Time;

class MatrixMultiply : public ScheduledKernel
{
public:
  MatrixMultiply()
    : m_hA(NULL), m_hB(NULL), m_hC(NULL), m_hCheckC(NULL),
      m_memBytesReadWrite(0), m_floatingPointOps(0)
  {}

  ~MatrixMultiply()
  {
    FreeHostMemory();
    FreeDeviceMemory();
  }

  void FreeHostMemory();
  void FreeDeviceMemory();

  void InitializeData(int matrixSize, int blockWidth, int kernelNum);
  void FinishHostExecution(bool freeHostMemory);

  virtual int  AcquireDeviceResources(std::vector< DeviceInfo > *deviceInfo);
  virtual void ReleaseDeviceResources(std::vector< DeviceInfo > *deviceInfo);

  int   m_matrixSize;
  int   m_blockWidth;
  float *m_hA, *m_hB, *m_hC, *m_hCheckC;

  std::size_t  m_globalMemRequired;
  int m_blocksRequired;

  float m_floatingPointOps;
  float m_MFLOPs;
  float m_memBytesReadWrite;
  float m_MBps;

  int m_kernelNum, m_deviceNum;
  float m_queueTimeMS, m_kernelExecTimeMS, m_totalExecTimeMS;

  Time m_queueStarted, m_streamStarted, m_streamFinished;
};

class BatchMatrixMultiply
{
public:
  BatchMatrixMultiply(int meanMatrixSize, int batchSize, int blockWidth)
    : m_meanMatrixSize(meanMatrixSize), m_blockWidth(blockWidth), m_batchSize(batchSize)
  {}

  ~BatchMatrixMultiply()
  {
    for (auto it = m_data.begin(); it != m_data.end(); ++it)
      if (*it) delete *it;
  }

  void RunExperiment(const std::string &kernelName, int numRepeat);
  void ComputeBatchResults();
  void OutputResultsCSV(const std::string &kernelName);
  friend void RunKernelThreaded(BatchMatrixMultiply *batch, int kernelNum);

private:
  void GenerateData();

  std::vector< MatrixMultiply* > m_data;
  int m_meanMatrixSize, m_blockWidth, m_batchSize;

  float m_batchTotalExecTimeMS;

  float m_batchFloatingPointOps;
  float m_batchGFLOPs;

  float m_batchMemBytesReadWrite;
  float m_batchGBps;
};

#endif // MATRIXMULTIPLY_CPU_HPP
