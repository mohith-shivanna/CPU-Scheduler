#ifndef SCHEDULER_CPU_HPP
#define SCHEDULER_CPU_HPP

#include <vector>
#include <mutex>
#include <cstddef>

class DeviceInfo
{
public:
  void SetDeviceInfo(int deviceNum);

  std::size_t m_totalGlobalMem, m_remainingGlobalMem;
  int m_totalBlocksDimX, m_remainingBlocksDimX;
  int m_totalCores, m_remainingTotalCores;
};

class ScheduledKernel
{
public:
  virtual int  AcquireDeviceResources(std::vector< DeviceInfo > *deviceInfo) = 0;
  virtual void ReleaseDeviceResources(std::vector< DeviceInfo > *deviceInfo) = 0;
};

class Scheduler
{
public:
  static void  GetDeviceInfo();

  static std::vector< DeviceInfo > m_deviceInfo;
  static int m_maxDevices;
  static bool m_verbose;
  static std::mutex m_deviceInfoMutex;
};

#endif // SCHEDULER_CPU_HPP
