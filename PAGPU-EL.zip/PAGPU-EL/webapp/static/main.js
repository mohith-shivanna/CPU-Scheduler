// Shared frontend functionality for all pages

// Dark mode toggle
function initDarkMode() {
  const toggle = document.getElementById('darkModeToggle');
  const isDark = localStorage.getItem('darkMode') === 'true';
  const body = document.getElementById('app-body');
  
  if (!body) return;
  
  if (isDark) {
    body.classList.add('dark-mode');
  }
  
  if (toggle) {
    toggle.addEventListener('click', () => {
      body.classList.toggle('dark-mode');
      const newState = body.classList.contains('dark-mode');
      localStorage.setItem('darkMode', newState);
    });
  }
}

// Help modal
function initHelp() {
  const toggle = document.getElementById('helpToggle');
  const modal = document.getElementById('helpModal');
  const closeBtn = modal ? modal.querySelector('.close-btn') : null;
  
  if (!modal) return;
  
  if (toggle) {
    toggle.addEventListener('click', (e) => {
      e.stopPropagation();
      modal.classList.toggle('hidden');
    });
  }
  
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      modal.classList.add('hidden');
    });
  }
  
  // Click outside modal to close
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.classList.add('hidden');
    }
  });
  
  // Keyboard shortcut: ? or Shift+/
  document.addEventListener('keydown', (e) => {
    if ((e.key === '?' || (e.shiftKey && e.key === '/')) && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
      e.preventDefault();
      modal.classList.toggle('hidden');
    }
    // Esc to close modal
    if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
      modal.classList.add('hidden');
    }
  });
}

// Keyboard shortcuts
function initShortcuts() {
  document.addEventListener('keydown', (e) => {
    const isInput = document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA';
    
    // D = Dark mode
    if (e.key === 'd' && e.ctrlKey && !isInput) {
      e.preventDefault();
      const darkToggle = document.getElementById('darkModeToggle');
      if (darkToggle) darkToggle.click();
    }
    
    // R = Run (on dashboard)
    if (e.key === 'r' && e.ctrlKey && !isInput) {
      e.preventDefault();
      const runBtn = document.getElementById('runBtn');
      if (runBtn) runBtn.click();
    }
  });
}

// Initialize all
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
      initDarkMode();
      initHelp();
      initShortcuts();
    }, 100);
  });
} else {
  initDarkMode();
  initHelp();
  initShortcuts();
}
