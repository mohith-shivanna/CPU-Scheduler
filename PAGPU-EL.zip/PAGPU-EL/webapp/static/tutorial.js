// Tutorial page interactivity

let currentStep = 0;
const totalSteps = 5;

function showStep(step) {
  if (step < 0 || step >= totalSteps) return;
  
  currentStep = step;
  
  // Hide all steps
  const allSteps = document.querySelectorAll('.tutorial-step');
  allSteps.forEach(el => {
    el.classList.remove('active');
  });
  
  // Show current step
  const activeStep = document.querySelector(`.tutorial-step[data-step="${step}"]`);
  if (activeStep) {
    activeStep.classList.add('active');
  }
  
  // Update buttons
  const allButtons = document.querySelectorAll('.tutorial-btn');
  allButtons.forEach(el => {
    el.classList.remove('active');
  });
  const activeBtn = document.querySelector(`.tutorial-btn[data-step="${step}"]`);
  if (activeBtn) {
    activeBtn.classList.add('active');
  }
  
  // Update nav buttons
  const prevBtn = document.getElementById('prevStep');
  const nextBtn = document.getElementById('nextStep');
  if (prevBtn) prevBtn.disabled = (step === 0);
  if (nextBtn) nextBtn.disabled = (step === totalSteps - 1);
  
  // Update step indicator
  const indicator = document.getElementById('currentStep');
  if (indicator) {
    indicator.textContent = step + 1;
  }
  
  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function initTutorial() {
  // Step button clicks
  document.querySelectorAll('.tutorial-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const step = parseInt(btn.getAttribute('data-step'));
      showStep(step);
    });
  });
  
  // Next/Prev buttons
  const nextBtn = document.getElementById('nextStep');
  const prevBtn = document.getElementById('prevStep');
  
  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      showStep(currentStep + 1);
    });
  }
  
  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      showStep(currentStep - 1);
    });
  }
  
  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      showStep(currentStep + 1);
    }
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      showStep(currentStep - 1);
    }
  });
  
  // Start at step 0
  showStep(0);
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initTutorial);
} else {
  initTutorial();
}
