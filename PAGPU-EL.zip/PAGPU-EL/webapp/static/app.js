let isRunning = false;

function showSpinner(show = true) {
  const spinner = document.getElementById('loadingSpinner');
  if (spinner) {
    if (show) spinner.classList.remove('hidden');
    else spinner.classList.add('hidden');
  }
}

function setStatus(state, message) {
  const banner = document.getElementById('statusBanner');
  if (!banner) return;
  const base = {
    idle: { text: `Status: Idle — ${message || 'ready to run experiments.'}` },
    running: { text: `Status: Running — ${message || 'executing...'}` },
    done: { text: `Status: Completed — ${message || 'finished.'}` },
    error: { text: `Status: Error — ${message || 'something went wrong.'}` },
  };
  banner.innerHTML = `<strong>${base[state] ? base[state].text.split(' — ')[0] : 'Status:'}</strong> ${base[state]?.text.split(' — ')[1] || ''}`;
}

function updateFormDefaults(kernel) {
  // Set sensible defaults based on kernel type
  const defaults = {
    'MultiplyAdd': {
      inputSize: 65536,
      kernelArg: 256
    },
    'MatrixMultiply': {
      inputSize: 256,  // Smaller for MatrixMultiply to avoid segfault on CPU
      kernelArg: 16
    }
  };
  
  const config = defaults[kernel] || defaults['MultiplyAdd'];
  document.getElementById('inputSize').value = config.inputSize;
  document.getElementById('kernelArg').value = config.kernelArg;
}

function updateConfigSummary() {
  const kernel = document.getElementById('kernel').value;
  const inputSize = document.getElementById('inputSize').value;
  const batchSize = document.getElementById('batchSize').value;
  const maxDevices = document.getElementById('maxDevices').value;
  const kernelArg = document.getElementById('kernelArg').value;
  const numRepeat = document.getElementById('numRepeat').value;
  const verbose = document.getElementById('verbose').value === '1' ? 'On' : 'Off';
  const root = document.getElementById('configSummary');
  if (!root) return;
  Array.from(root.querySelectorAll('span[data-key]')).forEach(span => {
    const key = span.getAttribute('data-key');
    const map = { kernel, inputSize, batchSize, maxDevices, kernelArg, numRepeat, verbose };
    if (key in map) span.textContent = map[key];
  });
}

function renderSummary(kernelRows, batchRows) {
  const root = document.getElementById('runSummary');
  if (!root) return;
  const kCount = (kernelRows || []).length;
  const avg = (arr, key) => {
    if (!arr || arr.length === 0) return 0;
    const s = arr.reduce((acc, r) => acc + Number(r[key] || 0), 0);
    return s / arr.length;
  };
  const min = (arr, key) => {
    if (!arr || arr.length === 0) return 0;
    return Math.min(...arr.map(r => Number(r[key] || 0)));
  };
  const max = (arr, key) => {
    if (!arr || arr.length === 0) return 0;
    return Math.max(...arr.map(r => Number(r[key] || 0)));
  };
  const totalBatchMS = (batchRows || []).reduce((acc, r) => acc + Number(r.BatchTotalExecTimeMS || 0), 0);
  const avgMFLOPs = avg(kernelRows, 'MFLOPs').toFixed(2);
  const avgMBps = avg(kernelRows, 'MBps').toFixed(2);
  const minMFLOPs = min(kernelRows, 'MFLOPs').toFixed(2);
  const maxMFLOPs = max(kernelRows, 'MFLOPs').toFixed(2);
  
  const values = {
    kernelCount: kCount,
    avgMFLOPs: `${avgMFLOPs} (${minMFLOPs}–${maxMFLOPs})`,
    avgMBps: avg(kernelRows, 'MBps').toFixed(2),
    totalBatchMS: totalBatchMS.toFixed(3),
  };
  Array.from(root.querySelectorAll('span[data-key]')).forEach(span => {
    const key = span.getAttribute('data-key');
    if (key in values) span.textContent = values[key];
  });
}

async function fetchResults(kernel) {
  const res = await fetch(`/results?kernel=${encodeURIComponent(kernel)}`);
  return await res.json();
}

function renderTablesAndCharts(kernelRows, batchRows) {
  const kernelTbody = document.querySelector('#kernelTable tbody');
  const batchTbody = document.querySelector('#batchTable tbody');
  kernelTbody.innerHTML = '';
  batchTbody.innerHTML = '';

  // Kernel table
  kernelRows.forEach(r => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${r.KernelNum}</td>
      <td>${Number(r.MFLOPs).toFixed(2)}</td>
      <td>${Number(r.MBps).toFixed(2)}</td>
      <td>${Number(r.QueueTimeMS).toFixed(3)}</td>
      <td>${Number(r.KernelExecTimeMS).toFixed(3)}</td>
      <td>${Number(r.TotalExecTimeMS).toFixed(3)}</td>
    `;
    kernelTbody.appendChild(tr);
  });

  // Batch table
  batchRows.forEach(r => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${r.BatchSize}</td>
      <td>${Number(r.GFLOPs).toFixed(2)}</td>
      <td>${Number(r.GBps).toFixed(2)}</td>
      <td>${Number(r.BatchTotalExecTimeMS).toFixed(3)}</td>
    `;
    batchTbody.appendChild(tr);
  });
}

async function runJob() {
  if (isRunning) return;
  isRunning = true;
  const btn = document.getElementById('runBtn');
  btn.disabled = true;
  showSpinner(true);
  setStatus('running', 'executing current configuration');
  const kernel = document.getElementById('kernel').value;
  const inputSize = Number(document.getElementById('inputSize').value);
  const batchSize = Number(document.getElementById('batchSize').value);
  const maxDevices = Number(document.getElementById('maxDevices').value);
  const kernelArg = Number(document.getElementById('kernelArg').value);
  const numRepeat = Number(document.getElementById('numRepeat').value);
  const verbose = Number(document.getElementById('verbose').value);

  const res = await fetch('/run', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ kernel, inputSize, batchSize, maxDevices, kernelArg, numRepeat, verbose })
  });
  const data = await res.json();

  document.getElementById('output').textContent = data.output || JSON.stringify(data, null, 2);

  // After run, refresh results
  const results = await fetchResults(kernel);
  renderTablesAndCharts(results.kernelRows || [], results.batchRows || []);
  renderSummary(results.kernelRows || [], results.batchRows || []);
  setStatus('done', `completed — ${results.batchRows?.length || 0} batch rows, ${results.kernelRows?.length || 0} kernel rows`);
  showSpinner(false);
  isRunning = false;
  btn.disabled = false;
}

async function init() {
  // Prevent double initialization (e.g., Flask debug reloader)
  if (window.__appInited) return;
  window.__appInited = true;

  document.getElementById('runBtn').addEventListener('click', runJob, { once: false });
  const kernel = document.getElementById('kernel').value;
  updateFormDefaults(kernel);  // Set defaults on page load
  const results = await fetchResults(kernel);
  renderTablesAndCharts(results.kernelRows || [], results.batchRows || []);
  renderSummary(results.kernelRows || [], results.batchRows || []);
  updateConfigSummary();
  setStatus('idle', 'ready to run experiments.');

  // Refresh results when kernel selection changes
  document.getElementById('kernel').addEventListener('change', async (e) => {
    const k = e.target.value;
    updateFormDefaults(k);  // Update input defaults
    const res = await fetchResults(k);
    renderTablesAndCharts(res.kernelRows || [], res.batchRows || []);
    renderSummary(res.kernelRows || [], res.batchRows || []);
    updateConfigSummary();
  }, { once: false });

  // History UI setup
  const historyKernelEl = document.getElementById('historyKernel');
  historyKernelEl.addEventListener('change', populateRuns, { once: false });
  document.getElementById('compareBtn').addEventListener('click', compareRuns, { once: false });
  await populateRuns();

  // CSV export
  document.querySelectorAll('.export-btn').forEach(btn => {
    btn.addEventListener('click', (e) => exportTableCSV(e.target.getAttribute('data-table')));
  });
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Charts removed: tables-only rendering

async function listRuns(kernel) {
  const res = await fetch(`/list_runs?kernel=${encodeURIComponent(kernel)}`);
  return await res.json();
}

async function populateRuns() {
  const kernel = document.getElementById('historyKernel').value;
  const data = await listRuns(kernel);
  const runA = document.getElementById('runA');
  const runB = document.getElementById('runB');
  runA.innerHTML = '';
  runB.innerHTML = '';
  (data.runs || []).forEach(r => {
    const o1 = document.createElement('option'); o1.value = r.id; o1.textContent = r.label;
    const o2 = document.createElement('option'); o2.value = r.id; o2.textContent = r.label;
    runA.appendChild(o1);
    runB.appendChild(o2);
  });
}

async function loadRun(kernel, id) {
  const res = await fetch(`/load_run?kernel=${encodeURIComponent(kernel)}&id=${encodeURIComponent(id)}`);
  return await res.json();
}

async function compareRuns() {
  const kernel = document.getElementById('historyKernel').value;
  const idA = document.getElementById('runA').value;
  const idB = document.getElementById('runB').value;
  if (!idA || !idB) return;
  const runA = await loadRun(kernel, idA);
  const runB = await loadRun(kernel, idB);

  // Populate tables for A/B
  setMeta('metaA', runA.meta);
  setMeta('metaB', runB.meta);
  populateBatchTable(runA.batchRows || [], 'batchCompareTableA');
  populateBatchTable(runB.batchRows || [], 'batchCompareTableB');
  populateKernelTable(runA.kernelRows || [], 'kernelCompareTableA');
  populateKernelTable(runB.kernelRows || [], 'kernelCompareTableB');

  // Render comparison chart
  renderComparisonChart(runA, runB);
}

function renderComparisonChart(runA, runB) {
  const container = document.getElementById('comparisonChart');
  const chartContainer = document.getElementById('comparisonChartContainer');
  if (!container) return;

  // Extract batch metrics for comparison
  const batchA = runA.batchRows && runA.batchRows.length > 0 ? runA.batchRows[0] : {};
  const batchB = runB.batchRows && runB.batchRows.length > 0 ? runB.batchRows[0] : {};

  // Find common comparable metrics across both kernels
  const allMetrics = Object.keys(batchA);
  const numericMetrics = ['GFLOPs', 'GBps', 'BatchTotalExecTimeMS', 'MFLOPs', 'MBps'];
  const metrics = allMetrics.filter(m => numericMetrics.includes(m) && batchA[m] && batchB[m]);
  
  if (metrics.length === 0) {
    console.warn('No comparable metrics found');
    chartContainer.style.display = 'none';
    return;
  }

  const runALabel = runA.meta ? `Run A (${runA.meta.timestamp})` : 'Run A';
  const runBLabel = runB.meta ? `Run B (${runB.meta.timestamp})` : 'Run B';

  const traces = metrics.map(metric => {
    return {
      x: [runALabel, runBLabel],
      y: [parseFloat(batchA[metric] || 0), parseFloat(batchB[metric] || 0)],
      type: 'bar',
      name: metric,
      text: [
        (parseFloat(batchA[metric] || 0)).toFixed(2),
        (parseFloat(batchB[metric] || 0)).toFixed(2)
      ],
      textposition: 'auto',
      hovertemplate: '<b>%{x}</b><br>' + metric + ': %{y:.2f}<extra></extra>'
    };
  });

  const layout = {
    title: {
      text: `Batch Performance Comparison: ${runA.meta?.kernel || 'Unknown'}`,
      font: { size: 16, color: '#333' }
    },
    barmode: 'group',
    xaxis: { title: 'Run' },
    yaxis: { title: 'Value' },
    margin: { l: 50, r: 50, t: 60, b: 50 },
    paper_bgcolor: 'rgba(240,240,240,0.5)',
    plot_bgcolor: 'rgba(255,255,255,0.8)',
    font: { family: 'system-ui, -apple-system, sans-serif', size: 12, color: '#333' },
    hovermode: 'closest',
    showlegend: true,
    legend: { x: 1.05, y: 1 }
  };

  const config = { responsive: true, displayModeBar: true };

  try {
    Plotly.newPlot(container, traces, layout, config);
    chartContainer.style.display = 'block';
  } catch (e) {
    console.error('Chart rendering failed:', e);
    chartContainer.style.display = 'none';
  }
}

function setMeta(id, meta) {
  const el = document.getElementById(id);
  if (!el) return;
  const label = meta ? `${meta.timestamp || ''} | in=${meta.inputSize} b=${meta.batchSize} d=${meta.maxDevices} arg=${meta.kernelArg}` : '';
  el.textContent = label;
}

function populateBatchTable(rows, tableId) {
  const table = document.querySelector(`#${tableId}`);
  if (!table) {
    console.error(`Table not found: ${tableId}`);
    return;
  }
  
  const tbody = table.querySelector('tbody');
  const thead = table.querySelector('thead tr');
  
  if (!tbody || !thead) {
    console.error(`tbody or thead not found in ${tableId}`);
    return;
  }
  
  if (!rows || rows.length === 0) {
    console.warn(`No rows to populate in ${tableId}`);
    return;
  }
  
  // Get all unique column names from data, sorted for consistency
  const columns = Object.keys(rows[0]).sort();
  console.log(`Populating ${tableId} with columns:`, columns);
  
  // Define numeric columns that should be formatted
  const numericCols = ['GFLOPs', 'GBps', 'MFLOPs', 'MBps', 'QueueTimeMS', 'KernelExecTimeMS', 
                       'TotalExecTimeMS', 'BatchTotalExecTimeMS', 'FloatingPtOps', 'MemBytes'];
  
  // Regenerate header
  thead.innerHTML = columns.map(col => 
    `<th>${col}</th>`
  ).join('');
  
  // Populate rows
  tbody.innerHTML = '';
  rows.forEach(r => {
    const tr = document.createElement('tr');
    const cells = columns.map(col => {
      let value = r[col] || '';
      // Format numeric values
      if (numericCols.includes(col) && value && value !== '') {
        value = parseFloat(value).toFixed(2);
      }
      return `<td>${value}</td>`;
    }).join('');
    tr.innerHTML = cells;
    tbody.appendChild(tr);
  });
  console.log(`Successfully populated ${tableId} with ${rows.length} rows`);
}

function populateKernelTable(rows, tableId) {
  const table = document.querySelector(`#${tableId}`);
  if (!table) {
    console.error(`Table not found: ${tableId}`);
    return;
  }
  
  const tbody = table.querySelector('tbody');
  const thead = table.querySelector('thead tr');
  
  if (!tbody || !thead) {
    console.error(`tbody or thead not found in ${tableId}`);
    return;
  }
  
  if (!rows || rows.length === 0) {
    console.warn(`No rows to populate in ${tableId}`);
    return;
  }
  
  // Get all unique column names from data, sorted for consistency
  const columns = Object.keys(rows[0]).sort();
  console.log(`Populating ${tableId} with columns:`, columns);
  
  // Define numeric columns that should be formatted
  const numericCols = ['GFLOPs', 'GBps', 'MFLOPs', 'MBps', 'QueueTimeMS', 'KernelExecTimeMS', 
                       'TotalExecTimeMS', 'BatchTotalExecTimeMS', 'FloatingPtOps', 'MemBytes'];
  
  // Regenerate header
  thead.innerHTML = columns.map(col => 
    `<th>${col}</th>`
  ).join('');
  
  // Populate rows
  tbody.innerHTML = '';
  rows.forEach(r => {
    const tr = document.createElement('tr');
    const cells = columns.map(col => {
      let value = r[col] || '';
      // Format numeric values
      if (numericCols.includes(col) && value && value !== '') {
        value = parseFloat(value).toFixed(2);
      }
      return `<td>${value}</td>`;
    }).join('');
    tr.innerHTML = cells;
    tbody.appendChild(tr);
  });
  console.log(`Successfully populated ${tableId} with ${rows.length} rows`);
}

function sum(arr, key) {
  return arr.reduce((acc, r) => acc + Number(r[key] || 0), 0);
}

function exportTableCSV(tableId) {
  const table = document.getElementById(tableId);
  if (!table) return;
  const rows = [];
  const headers = Array.from(table.querySelectorAll('th')).map(th => th.textContent.trim());
  rows.push(headers.join(','));
  table.querySelectorAll('tbody tr').forEach(tr => {
    const cells = Array.from(tr.querySelectorAll('td')).map(td => {
      const text = td.textContent.trim();
      return text.includes(',') ? `"${text}"` : text;
    });
    rows.push(cells.join(','));
  });
  const csv = rows.join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${tableId}-export-${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  window.URL.revokeObjectURL(url);
}
