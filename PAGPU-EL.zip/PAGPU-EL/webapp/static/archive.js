// Results Archive page

let allRuns = [];
let filteredRuns = [];

async function loadArchive() {
  const container = document.getElementById('archiveContent');
  if (!container) return;
  
  try {
    container.innerHTML = '<p class="loading">Loading archive...</p>';
    
    // Load all kernels
    const multiplyAddRuns = await fetch('/list_runs?kernel=MultiplyAdd').then(r => r.json()).catch(() => ({ runs: [] }));
    const matrixMultiplyRuns = await fetch('/list_runs?kernel=MatrixMultiply').then(r => r.json()).catch(() => ({ runs: [] }));
    
    allRuns = [
      ...(multiplyAddRuns.runs || []).map(r => ({ ...r, kernel: 'MultiplyAdd' })),
      ...(matrixMultiplyRuns.runs || []).map(r => ({ ...r, kernel: 'MatrixMultiply' }))
    ];
    
    filterAndDisplay();
  } catch (e) {
    console.error('Archive load error:', e);
    container.innerHTML = '<p class="error">Failed to load archive</p>';
  }
}

function filterAndDisplay() {
  const kernelFilter = document.getElementById('filterKernel');
  const searchInput = document.getElementById('searchInput');
  const sortBy = document.getElementById('sortBy');
  
  const kernel = kernelFilter ? kernelFilter.value : '';
  const search = searchInput ? searchInput.value.toLowerCase() : '';
  const sort = sortBy ? sortBy.value : 'date-desc';
  
  filteredRuns = allRuns.filter(run => {
    const matchKernel = !kernel || run.kernel === kernel;
    const matchSearch = !search || run.label.toLowerCase().includes(search) || run.id.toLowerCase().includes(search);
    return matchKernel && matchSearch;
  });
  
  // Sort
  if (sort === 'date-desc') {
    filteredRuns.sort((a, b) => {
      const dateA = new Date(a.label.split(' ')[0]).getTime();
      const dateB = new Date(b.label.split(' ')[0]).getTime();
      return dateB - dateA;
    });
  } else if (sort === 'date-asc') {
    filteredRuns.sort((a, b) => {
      const dateA = new Date(a.label.split(' ')[0]).getTime();
      const dateB = new Date(b.label.split(' ')[0]).getTime();
      return dateA - dateB;
    });
  } else if (sort === 'kernel') {
    filteredRuns.sort((a, b) => a.kernel.localeCompare(b.kernel));
  }
  
  renderArchive();
}

function renderArchive() {
  const container = document.getElementById('archiveContent');
  if (!container) return;
  
  if (filteredRuns.length === 0) {
    container.innerHTML = '<p class="empty-state">No runs found. Run an experiment on the Dashboard to create entries.</p>';
    return;
  }
  
  container.innerHTML = filteredRuns.map((run, idx) => `
    <div class="archive-item">
      <div class="item-header">
        <h3>
          <span class="kernel-badge">${run.kernel}</span>
          ${run.id}
        </h3>
        <p class="item-label">${run.label}</p>
      </div>
      <div class="item-actions">
        <button class="btn-small" onclick="window.viewRunDetail('${run.kernel}', '${run.id}')">View</button>
      </div>
    </div>
  `).join('');
}

window.viewRunDetail = function(kernel, id) {
  const modal = document.getElementById('runDetailModal');
  const body = document.getElementById('runDetailBody');
  
  if (!modal || !body) return;
  
  fetch(`/load_run?kernel=${encodeURIComponent(kernel)}&id=${encodeURIComponent(id)}`)
    .then(r => r.json())
    .then(data => {
      body.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
          <div>
            <h2>${kernel} - ${id}</h2>
            <p>${data.meta ? data.meta.timestamp : 'No timestamp'}</p>
          </div>
          <button id="deleteRunBtn" class="btn-danger" style="margin-left: 10px;">Delete Run</button>
        </div>
        <h3>Batch Results</h3>
        <table class="modal-table">
          <thead>
            <tr>
              <th>BatchSize</th><th>GFLOPs</th><th>GBps</th><th>TotalExecTimeMS</th>
            </tr>
          </thead>
          <tbody>
            ${(data.batchRows || []).map(r => `
              <tr>
                <td>${r.BatchSize}</td>
                <td>${Number(r.GFLOPs).toFixed(2)}</td>
                <td>${Number(r.GBps).toFixed(2)}</td>
                <td>${Number(r.BatchTotalExecTimeMS).toFixed(3)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        <h3>Kernel Results</h3>
        <table class="modal-table">
          <thead>
            <tr>
              <th>KernelNum</th><th>MFLOPs</th><th>MBps</th><th>QueueMS</th><th>KernelMS</th><th>TotalMS</th>
            </tr>
          </thead>
          <tbody>
            ${(data.kernelRows || []).map(r => `
              <tr>
                <td>${r.KernelNum}</td>
                <td>${Number(r.MFLOPs).toFixed(2)}</td>
                <td>${Number(r.MBps).toFixed(2)}</td>
                <td>${Number(r.QueueTimeMS).toFixed(3)}</td>
                <td>${Number(r.KernelExecTimeMS).toFixed(3)}</td>
                <td>${Number(r.TotalExecTimeMS).toFixed(3)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
      
      // Attach delete handler
      const deleteBtn = document.getElementById('deleteRunBtn');
      if (deleteBtn) {
        deleteBtn.addEventListener('click', () => {
          if (confirm(`Delete run ${id}? This cannot be undone.`)) {
            fetch('/delete_run', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ kernel: kernel, id: id })
            })
            .then(r => r.json())
            .then(data => {
              if (data.success) {
                alert(data.message);
                modal.classList.add('hidden');
                loadArchive();
              } else {
                alert('Error: ' + (data.error || 'Failed to delete'));
              }
            })
            .catch(e => alert('Error: ' + e.message));
          }
        });
      }
      
      modal.classList.remove('hidden');
    })
    .catch(e => {
      console.error('Failed to load run detail:', e);
      body.innerHTML = '<p class="error">Failed to load run details</p>';
      modal.classList.remove('hidden');
    });
};

function initArchive() {
  const filterKernel = document.getElementById('filterKernel');
  const searchInput = document.getElementById('searchInput');
  const sortBy = document.getElementById('sortBy');
  const deleteAllBtn = document.getElementById('deleteAllBtn');
  const modal = document.getElementById('runDetailModal');
  
  if (filterKernel) {
    filterKernel.addEventListener('change', filterAndDisplay);
  }
  
  if (searchInput) {
    searchInput.addEventListener('input', filterAndDisplay);
  }
  
  if (sortBy) {
    sortBy.addEventListener('change', filterAndDisplay);
  }
  
  if (deleteAllBtn) {
    deleteAllBtn.addEventListener('click', () => {
      const kernel = document.getElementById('filterKernel');
      const selectedKernel = kernel ? kernel.value || 'MultiplyAdd' : 'MultiplyAdd';
      
      if (confirm(`Delete all archived runs for ${selectedKernel}? This cannot be undone.`)) {
        fetch('/delete_all', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ kernel: selectedKernel })
        })
        .then(r => r.json())
        .then(data => {
          if (data.success) {
            alert(data.message);
            loadArchive();
          } else {
            alert('Error: ' + (data.error || 'Failed to delete'));
          }
        })
        .catch(e => alert('Error: ' + e.message));
      }
    });
  }
  
  // Close modal
  if (modal) {
    const closeBtn = modal.querySelector('.close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        modal.classList.add('hidden');
      });
    }
    
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.add('hidden');
      }
    });
  }
  
  loadArchive();
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initArchive);
} else {
  initArchive();
}
