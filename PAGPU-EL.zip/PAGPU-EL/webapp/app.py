from flask import Flask, render_template, request, jsonify
import subprocess
import os
import csv
from pathlib import Path
import json
import shutil
from datetime import datetime

app = Flask(__name__)

# Default executable path; can be overridden via env var FRONTEND_EXEC
ROOT = Path(__file__).resolve().parent.parent
RESULTS_DIR = ROOT / "webapp" / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
DEFAULT_EXEC = ROOT / "build-macos" / "sched"
EXECUTABLE = Path(os.environ.get("FRONTEND_EXEC", str(DEFAULT_EXEC)))

# CSV filenames per kernel
KERNEL_FILES = {
    "MultiplyAdd": {
        "kernel": "MultiplyAddKernelResults.csv",
        "batch": "MultiplyAddBatchResults.csv",
    },
    "MatrixMultiply": {
        "kernel": "MatrixMultiplyKernelResults.csv",
        "batch": "MatrixMultiplyBatchResults.csv",
    },
}


def read_csv(file_path):
    rows = []
    if Path(file_path).exists():
        with open(file_path, newline="") as f:
            reader = csv.DictReader(f)
            # Normalize header names to strip leading/trailing spaces
            if reader.fieldnames:
                reader.fieldnames = [fn.strip() for fn in reader.fieldnames]
            for row in reader:
                # Normalize keys and string values
                norm = {}
                for k, v in row.items():
                    kk = k.strip() if isinstance(k, str) else k
                    vv = v.strip() if isinstance(v, str) else v
                    norm[kk] = vv
                rows.append(norm)
    return rows


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/tutorial")
def tutorial():
    return render_template("tutorial.html")


@app.route("/results-archive")
def results_archive():
    return render_template("results_archive.html")


@app.route("/run", methods=["POST"])
def run_job():
    data = request.get_json(force=True)
    kernel = data.get("kernel", "MultiplyAdd")
    inputSize = int(data.get("inputSize", 65536))
    batchSize = int(data.get("batchSize", 8))
    maxDevices = int(data.get("maxDevices", 2))
    kernelArg = int(data.get("kernelArg", 256))
    numRepeat = int(data.get("numRepeat", 1))
    verbose = int(data.get("verbose", 1))

    if kernel not in KERNEL_FILES:
        return jsonify({"error": "Unsupported kernel"}), 400

    if not EXECUTABLE.exists():
        return jsonify({"error": f"Executable not found at {EXECUTABLE}"}), 404

    # Ensure CSVs start fresh (optional)
    for key in ("kernel", "batch"):
        csv_path = ROOT / KERNEL_FILES[kernel][key]
        try:
            if csv_path.exists():
                os.remove(csv_path)
        except Exception:
            pass

    # Build arg list matching main.cpp usage
    args = [
        str(EXECUTABLE),
        str(inputSize),
        str(batchSize),
        str(maxDevices),
        kernel,
        str(kernelArg),
        str(numRepeat),
        str(verbose),
    ]

    try:
        # Run from webapp folder so CSVs are written next to this app
        proc = subprocess.run(
            args,
            cwd=str(ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            check=False,
        )
        output = proc.stdout
        status = proc.returncode
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    # Read results back
    kernel_rows = read_csv(ROOT / KERNEL_FILES[kernel]["kernel"])  # list[dict]
    batch_rows = read_csv(ROOT / KERNEL_FILES[kernel]["batch"])    # list[dict]

    # Snapshot results for history/comparison
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    run_id = f"{ts}-in{inputSize}-b{batchSize}-d{maxDevices}-arg{kernelArg}-rep{numRepeat}"
    snap_dir = RESULTS_DIR / kernel / run_id
    snap_dir.mkdir(parents=True, exist_ok=True)
    # Copy CSVs
    try:
        shutil.copy2(ROOT / KERNEL_FILES[kernel]["kernel"], snap_dir / KERNEL_FILES[kernel]["kernel"])
        shutil.copy2(ROOT / KERNEL_FILES[kernel]["batch"], snap_dir / KERNEL_FILES[kernel]["batch"])
    except Exception:
        pass
    # Write metadata
    meta = {
        "kernel": kernel,
        "inputSize": inputSize,
        "batchSize": batchSize,
        "maxDevices": maxDevices,
        "kernelArg": kernelArg,
        "numRepeat": numRepeat,
        "verbose": verbose,
        "runId": run_id,
        "timestamp": ts,
    }
    with open(snap_dir / "metadata.json", "w") as mf:
        json.dump(meta, mf)

    return jsonify({
        "status": status,
        "output": output,
        "kernelRows": kernel_rows,
        "batchRows": batch_rows,
        "runId": run_id,
    })


@app.route("/results", methods=["GET"])
def get_results():
    kernel = request.args.get("kernel", "MultiplyAdd")
    if kernel not in KERNEL_FILES:
        return jsonify({"error": "Unsupported kernel"}), 400

    kernel_rows = read_csv(ROOT / KERNEL_FILES[kernel]["kernel"])  # list[dict]
    batch_rows = read_csv(ROOT / KERNEL_FILES[kernel]["batch"])    # list[dict]
    return jsonify({
        "kernelRows": kernel_rows,
        "batchRows": batch_rows,
    })


@app.route("/list_runs", methods=["GET"])
def list_runs():
    kernel = request.args.get("kernel", "MultiplyAdd")
    if kernel not in KERNEL_FILES:
        return jsonify({"error": "Unsupported kernel"}), 400
    runs = []
    kdir = RESULTS_DIR / kernel
    if kdir.exists():
        for run_dir in sorted(kdir.iterdir()):
            if run_dir.is_dir():
                meta_path = run_dir / "metadata.json"
                if meta_path.exists():
                    try:
                        with open(meta_path) as mf:
                            meta = json.load(mf)
                        runs.append({
                            "id": meta.get("runId", run_dir.name),
                            "label": f"{meta.get('timestamp')} | in={meta.get('inputSize')} b={meta.get('batchSize')} d={meta.get('maxDevices')} arg={meta.get('kernelArg')}",
                        })
                    except Exception:
                        runs.append({"id": run_dir.name, "label": run_dir.name})
                else:
                    runs.append({"id": run_dir.name, "label": run_dir.name})
    return jsonify({"runs": runs})


@app.route("/load_run", methods=["GET"])
def load_run():
    kernel = request.args.get("kernel", "MultiplyAdd")
    run_id = request.args.get("id")
    if kernel not in KERNEL_FILES:
        return jsonify({"error": "Unsupported kernel"}), 400
    if not run_id:
        return jsonify({"error": "Missing run id"}), 400
    snap_dir = RESULTS_DIR / kernel / run_id
    if not snap_dir.exists():
        return jsonify({"error": "Run not found"}), 404
    kernel_rows = read_csv(snap_dir / KERNEL_FILES[kernel]["kernel"])  # list[dict]
    batch_rows = read_csv(snap_dir / KERNEL_FILES[kernel]["batch"])    # list[dict]
    meta = {}
    mp = snap_dir / "metadata.json"
    if mp.exists():
        try:
            with open(mp) as mf:
                meta = json.load(mf)
        except Exception:
            meta = {}
    return jsonify({
        "kernelRows": kernel_rows,
        "batchRows": batch_rows,
        "meta": meta,
    })


@app.route("/delete_run", methods=["POST"])
def delete_run():
    """Delete a specific archived run"""
    data = request.get_json(force=True)
    kernel = data.get("kernel")
    run_id = data.get("id")
    
    if kernel not in KERNEL_FILES:
        return jsonify({"error": "Unsupported kernel"}), 400
    if not run_id:
        return jsonify({"error": "Missing run id"}), 400
    
    snap_dir = RESULTS_DIR / kernel / run_id
    if not snap_dir.exists():
        return jsonify({"error": "Run not found"}), 404
    
    try:
        shutil.rmtree(snap_dir)
        return jsonify({"success": True, "message": f"Run {run_id} deleted"})
    except Exception as e:
        return jsonify({"error": f"Failed to delete run: {str(e)}"}), 500


@app.route("/delete_all", methods=["POST"])
def delete_all():
    """Delete all archived runs for a specific kernel"""
    data = request.get_json(force=True)
    kernel = data.get("kernel", "MultiplyAdd")
    
    if kernel not in KERNEL_FILES:
        return jsonify({"error": "Unsupported kernel"}), 400
    
    kdir = RESULTS_DIR / kernel
    if not kdir.exists():
        return jsonify({"success": True, "message": "No runs to delete"})
    
    try:
        # Delete all subdirectories (runs) in the kernel directory
        for run_dir in kdir.iterdir():
            if run_dir.is_dir():
                shutil.rmtree(run_dir)
        return jsonify({"success": True, "message": f"All {kernel} runs deleted"})
    except Exception as e:
        return jsonify({"error": f"Failed to delete runs: {str(e)}"}), 500


if __name__ == "__main__":
    # Run without reloader to avoid double-initialization in debug mode.
    port = int(os.environ.get("PORT", "5000"))
    try:
        app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)
    except OSError as e:
        # Fallback to next port if the address is already in use
        if "Address already in use" in str(e):
            app.run(host="127.0.0.1", port=port + 1, debug=False, use_reloader=False)
        else:
            raise
